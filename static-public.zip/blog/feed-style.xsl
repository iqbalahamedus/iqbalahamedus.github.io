<?xml version="1.0" encoding="UTF-8"?>
<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform">
  <xsl:output method="html" encoding="UTF-8" omit-xml-declaration="yes"/>
  <xsl:template match="/">
    <html lang="en">
      <head>
        <meta charset="UTF-8"/>
        <meta name="viewport" content="width=device-width, initial-scale=1"/>
        <title><xsl:value-of select="rss/channel/title"/> · RSS feed</title>
        <style type="text/css">
          :root { color-scheme: light dark; }
          * { box-sizing: border-box; }
          body { margin: 0; background: #f4faf7; color: #18352d; font: 17px/1.65 system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif; }
          main { width: min(100% - 32px, 920px); margin: 0 auto; padding: clamp(48px, 8vw, 96px) 0; }
          header { padding: clamp(28px, 5vw, 52px); border: 1px solid #9dcbbb; border-radius: 28px; background: #e8f5ef; }
          .eyebrow { margin: 0 0 10px; color: #19705f; font-size: .82rem; font-weight: 800; letter-spacing: .13em; text-transform: uppercase; }
          h1 { max-width: 760px; margin: 0; font: 700 clamp(2.3rem, 7vw, 4.8rem)/.98 Georgia, serif; letter-spacing: -.045em; }
          header p { max-width: 680px; margin: 24px 0 0; }
          .actions { display: flex; flex-wrap: wrap; gap: 12px; margin-top: 28px; }
          .button { display: inline-flex; min-height: 48px; align-items: center; padding: 10px 18px; border: 1px solid #19705f; border-radius: 999px; color: #f7fffb; background: #19705f; font-weight: 750; text-decoration: none; }
          .feed-url { display: block; overflow-wrap: anywhere; margin-top: 18px; color: #315a50; font-size: .9rem; }
          section { margin-top: 48px; }
          h2 { margin: 0 0 18px; font: 700 clamp(1.6rem, 4vw, 2.25rem)/1.15 Georgia, serif; }
          article { padding: 24px 0; border-top: 1px solid #b9d8cd; }
          article:last-child { border-bottom: 1px solid #b9d8cd; }
          article h3 { margin: 0; font-size: 1.25rem; line-height: 1.3; }
          article h3 a { color: #145d4f; text-decoration-thickness: .09em; text-underline-offset: .2em; }
          article p { margin: 10px 0 0; }
          time { display: block; margin-top: 12px; color: #52756b; font-size: .88rem; }
          @media (prefers-color-scheme: dark) {
            body { background: #071a18; color: #e4f4ee; }
            header { border-color: #315f55; background: #102c28; }
            .eyebrow { color: #78d9ba; }
            .button { border-color: #78d9ba; color: #06201b; background: #78d9ba; }
            .feed-url, time { color: #a9c8be; }
            article { border-color: #315f55; }
            article h3 a { color: #91e7cb; }
          }
        </style>
      </head>
      <body>
        <main>
          <header>
            <p class="eyebrow">Research notebook · RSS feed</p>
            <h1><xsl:value-of select="rss/channel/title"/></h1>
            <p>This page is working. It is an RSS feed—a simple way to receive new articles without checking the website. Copy the address below into any RSS reader, or browse the articles normally.</p>
            <div class="actions">
              <a class="button" href="/blog/">Browse the blog →</a>
            </div>
            <code class="feed-url">https://iqbalahamed.com/blog/feed.xml</code>
          </header>
          <section>
            <h2>Latest articles</h2>
            <xsl:for-each select="rss/channel/item">
              <article>
                <h3><a href="{link}"><xsl:value-of select="title"/></a></h3>
                <p><xsl:value-of select="description"/></p>
                <time><xsl:value-of select="pubDate"/></time>
              </article>
            </xsl:for-each>
          </section>
        </main>
      </body>
    </html>
  </xsl:template>
</xsl:stylesheet>